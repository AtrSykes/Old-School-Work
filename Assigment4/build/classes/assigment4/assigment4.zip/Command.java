/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assigment3;

import java.awt.event.MouseEvent;

/**
 *
 * @author Adam Sykes
 */
public interface Command {
    
    public void act(MouseEvent e);
    public void Undo();
    public void reAct();
}
