/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.geom.Rectangle2D;
import java.util.*;

/**
 *
 * @author Adam Sykes
 */
public class Model {
    static List<Rectangle2D.Double> list = new ArrayList<>();
    
    public static final void getRect(){
        Rectangle2D.Double rect1 = new Rectangle2D.Double(275.0,75.0,50.0,50.0);
        Rectangle2D.Double rect2 = new Rectangle2D.Double(75.0,210.0,50.0,50.0);
        Rectangle2D.Double rect3 = new Rectangle2D.Double(475.0,210.0,50.0,50.0);
        Rectangle2D.Double rect4 = new Rectangle2D.Double(150.0,425.0,50.0,50.0);
        Rectangle2D.Double rect5 = new Rectangle2D.Double(400.0,425.0,50.0,50.0);
        list.add(rect1);
        list.add(rect2);
        list.add(rect3);
        list.add(rect4);
        list.add(rect5);
    }
}
